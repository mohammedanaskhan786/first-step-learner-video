import React from 'react';
import {Composition} from 'remotion';
import {FirstStepLearner} from './FirstStepLearner';
import {SCENES} from './sceneData';
export const RemotionRoot: React.FC = () => <Composition id="FirstStepLearner60" component={FirstStepLearner} durationInFrames={3600*30} fps={30} width={1920} height={1080} defaultProps={{scenes:SCENES}} />;
