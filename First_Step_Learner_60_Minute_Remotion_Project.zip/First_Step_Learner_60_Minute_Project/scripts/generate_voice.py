import asyncio,json,os
from pathlib import Path
import edge_tts
ROOT=Path(__file__).resolve().parents[1]; DATA=json.loads((ROOT/"src/sceneData.json").read_text(encoding="utf-8")); OUT=ROOT/"public/audio"; OUT.mkdir(parents=True,exist_ok=True)
VOICE=os.getenv("TTS_VOICE","hi-IN-MadhurNeural")
async def one(s):
 p=OUT/f"{s['id']}.mp3"
 if p.exists() and p.stat().st_size>1000:return
 await edge_tts.Communicate(s["vo"],VOICE,rate=os.getenv("TTS_RATE","-5%"),pitch=os.getenv("TTS_PITCH","-1Hz")).save(str(p))
async def main():
 for i in range(0,len(DATA),4): await asyncio.gather(*(one(s) for s in DATA[i:i+4]))
 print("TTS complete",VOICE)
asyncio.run(main())
