#!/usr/bin/env bash
# One-command pipeline: script.txt + audio -> final MP4.
set -euo pipefail

SCRIPT_PATH="${1:?Usage: ./run_pipeline.sh <script.txt> <audio.mp3|wav>}"
AUDIO_PATH="${2:?Usage: ./run_pipeline.sh <script.txt> <audio.mp3|wav>}"

echo "== Step 1/2: Building timeline.json from script + audio =="
python3 pipeline/generate_timeline.py --script "$SCRIPT_PATH" --audio "$AUDIO_PATH"

echo "== Step 2/2: Rendering final 1080p30 MP4 with Remotion =="
cd remotion
npm run render

echo ""
echo "Done. Output: remotion/out/first-step-learner.mp4"
