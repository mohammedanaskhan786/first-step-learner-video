import { Config } from "@remotion/cli/config";

// High-bitrate, YouTube-ready defaults. Override any of these on the
// command line if you need to (e.g. --crf=20 for a smaller file).
Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
Config.setCodec("h264");
Config.setCrf(16);
Config.setPixelFormat("yuv420p");
