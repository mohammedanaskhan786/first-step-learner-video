import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { COLORS, FONT_FAMILY } from "../constants";

// A minimalist "app window" mockup — mac-style traffic-light dots on a
// title bar, glass body below. Used to show a chat/prompt UI (e.g.
// "User asks X, AI answers Y") without needing a real screen recording.
export interface WindowMessage {
  role: "user" | "ai";
  text: string;
}

export const WindowMockup: React.FC<{ title: string; messages: WindowMessage[] }> = ({
  title,
  messages,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const enter = spring({ frame, fps, config: { damping: 200 } });
  const scale = interpolate(enter, [0, 1], [0.94, 1]);
  const opacity = interpolate(enter, [0, 1], [0, 1]);

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
      <div
        style={{
          width: "68%",
          maxWidth: 980,
          borderRadius: 18,
          overflow: "hidden",
          background: "rgba(255,255,255,0.035)",
          border: "1px solid rgba(123,47,247,0.3)",
          boxShadow: "0 0 70px rgba(123,47,247,0.15)",
          backdropFilter: "blur(14px)",
          transform: `scale(${scale})`,
          opacity,
        }}
      >
        {/* Title bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "16px 22px",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            background: "rgba(255,255,255,0.02)",
          }}
        >
          <Dot color="#FF5F57" />
          <Dot color="#FEBC2E" />
          <Dot color="#28C840" />
          <div
            style={{
              marginLeft: 12,
              fontFamily: FONT_FAMILY,
              fontSize: 18,
              fontWeight: 600,
              color: COLORS.textSecondary,
              letterSpacing: 0.5,
            }}
          >
            {title}
          </div>
        </div>

        {/* Body */}
        <div style={{ padding: "36px 40px", display: "flex", flexDirection: "column", gap: 22 }}>
          {messages.map((m, i) => {
            const msgEnter = spring({ frame: frame - 6 - i * 6, fps, config: { damping: 200 } });
            const msgOpacity = interpolate(msgEnter, [0, 1], [0, 1]);
            const msgY = interpolate(msgEnter, [0, 1], [12, 0]);
            const isAi = m.role === "ai";
            return (
              <div
                key={i}
                style={{
                  alignSelf: isAi ? "flex-start" : "flex-end",
                  maxWidth: "85%",
                  opacity: msgOpacity,
                  transform: `translateY(${msgY}px)`,
                }}
              >
                <div
                  style={{
                    fontFamily: FONT_FAMILY,
                    fontSize: 15,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: 1.5,
                    color: isAi ? COLORS.accentSoft : COLORS.textSecondary,
                    marginBottom: 8,
                  }}
                >
                  {isAi ? "AI" : "You"}
                </div>
                <div
                  style={{
                    fontFamily: FONT_FAMILY,
                    fontSize: 26,
                    fontWeight: 500,
                    lineHeight: 1.5,
                    color: COLORS.textPrimary,
                    padding: "16px 20px",
                    borderRadius: 14,
                    background: isAi ? "rgba(123,47,247,0.12)" : "rgba(255,255,255,0.05)",
                    border: isAi ? "1px solid rgba(123,47,247,0.3)" : "1px solid rgba(255,255,255,0.07)",
                  }}
                >
                  {m.text}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Dot: React.FC<{ color: string }> = ({ color }) => (
  <div style={{ width: 12, height: 12, borderRadius: "50%", background: color, opacity: 0.85 }} />
);
