import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { COLORS, FONT_FAMILY } from "../constants";

// Minimalist "glass" card: translucent panel, thin violet border, soft
// outer glow, subtle scale/fade entrance.
export const GlassCard: React.FC<{ text: string }> = ({ text }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const enter = spring({ frame, fps, config: { damping: 200 } });
  const scale = interpolate(enter, [0, 1], [0.9, 1]);
  const opacity = interpolate(enter, [0, 1], [0, 1]);

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
      <div
        style={{
          width: "70%",
          padding: "60px 70px",
          borderRadius: 28,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(123,47,247,0.35)",
          boxShadow: "0 0 60px rgba(123,47,247,0.15)",
          backdropFilter: "blur(12px)",
          transform: `scale(${scale})`,
          opacity,
        }}
      >
        <div style={{ width: 56, height: 4, background: COLORS.accent, borderRadius: 2, marginBottom: 28 }} />
        <div
          style={{
            fontFamily: FONT_FAMILY,
            fontSize: 44,
            fontWeight: 600,
            color: COLORS.textPrimary,
            lineHeight: 1.4,
          }}
        >
          {text}
        </div>
      </div>
    </AbsoluteFill>
  );
};
