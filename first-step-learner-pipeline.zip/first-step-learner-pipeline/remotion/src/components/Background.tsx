import React, { useMemo } from "react";
import { AbsoluteFill, random, useCurrentFrame, useVideoConfig } from "remotion";
import { COLORS } from "../constants";

// Deep-black backdrop with a slow-drifting "neural network" particle
// field — small nodes with faint connecting lines, plus a soft violet
// vignette so on-screen text always has contrast to sit on top of.
const PARTICLE_COUNT = 40;

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();

  const particles = useMemo(() => {
    return new Array(PARTICLE_COUNT).fill(0).map((_, i) => {
      const seed = `particle-${i}`;
      return {
        x: random(seed + "x") * width,
        y: random(seed + "y") * height,
        size: 1.5 + random(seed + "s") * 3,
        speed: 0.15 + random(seed + "v") * 0.35,
        drift: (random(seed + "d") - 0.5) * 40,
        seed,
      };
    });
  }, [width, height]);

  return (
    <AbsoluteFill style={{ backgroundColor: COLORS.background }}>
      <svg width={width} height={height} style={{ position: "absolute", inset: 0 }}>
        {particles.map((p, i) => {
          if (i % 4 !== 0) return null;
          const partner = particles[(i + 5) % particles.length];
          const y1 = ((p.y - frame * p.speed) % (height + 100) + height + 100) % (height + 100);
          const y2 =
            ((partner.y - frame * partner.speed) % (height + 100) + height + 100) %
            (height + 100);
          return (
            <line
              key={`line-${p.seed}`}
              x1={p.x}
              y1={y1}
              x2={partner.x}
              y2={y2}
              stroke={COLORS.accent}
              strokeWidth={0.5}
              opacity={0.08}
            />
          );
        })}
        {particles.map((p) => {
          const y = ((p.y - frame * p.speed) % (height + 100) + height + 100) % (height + 100);
          const x = p.x + Math.sin(frame / 60 + p.drift) * 15;
          const opacity = 0.15 + 0.25 * Math.abs(Math.sin((frame + p.drift) / 90));
          return (
            <circle key={p.seed} cx={x} cy={y} r={p.size} fill={COLORS.accentSoft} opacity={opacity} />
          );
        })}
      </svg>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(123,47,247,0.08) 0%, rgba(10,10,10,0) 60%)",
        }}
      />
    </AbsoluteFill>
  );
};
