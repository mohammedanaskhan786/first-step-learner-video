import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { COLORS, FONT_FAMILY } from "../constants";

// Two panels sliding in from opposite sides — the "Basic Prompt vs
// Engineered System" comparison shot. Right panel gets the violet
// accent border/glow to signal "the better version".
export const SplitScreen: React.FC<{
  leftLabel: string;
  rightLabel: string;
  leftText: string;
  rightText: string;
}> = ({ leftLabel, rightLabel, leftText, rightText }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const slideLeft = spring({ frame, fps, config: { damping: 200 } });
  const slideRight = spring({ frame: frame - 4, fps, config: { damping: 200 } });

  const leftX = interpolate(slideLeft, [0, 1], [-60, 0]);
  const rightX = interpolate(slideRight, [0, 1], [60, 0]);

  const panelStyle: React.CSSProperties = {
    flex: 1,
    height: "72%",
    borderRadius: 24,
    padding: 50,
    display: "flex",
    flexDirection: "column",
    background: "rgba(255,255,255,0.03)",
  };

  return (
    <AbsoluteFill
      style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 24, padding: "0 60px" }}
    >
      <div style={{ ...panelStyle, border: "1px solid rgba(255,255,255,0.08)", transform: `translateX(${leftX}px)` }}>
        <Label text={leftLabel} accent={false} />
        <Body text={leftText} />
      </div>

      <div
        style={{
          width: 2,
          height: "60%",
          background: `linear-gradient(180deg, transparent, ${COLORS.accent}, transparent)`,
        }}
      />

      <div
        style={{
          ...panelStyle,
          border: `1px solid ${COLORS.accent}`,
          boxShadow: "0 0 50px rgba(123,47,247,0.2)",
          transform: `translateX(${rightX}px)`,
        }}
      >
        <Label text={rightLabel} accent />
        <Body text={rightText} />
      </div>
    </AbsoluteFill>
  );
};

const Label: React.FC<{ text: string; accent: boolean }> = ({ text, accent }) => (
  <div
    style={{
      fontFamily: FONT_FAMILY,
      fontSize: 26,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: 2,
      color: accent ? COLORS.accentSoft : COLORS.textSecondary,
      marginBottom: 24,
    }}
  >
    {text}
  </div>
);

const Body: React.FC<{ text: string }> = ({ text }) => (
  <div style={{ fontFamily: FONT_FAMILY, fontSize: 32, fontWeight: 500, color: COLORS.textPrimary, lineHeight: 1.5 }}>
    {text}
  </div>
);
