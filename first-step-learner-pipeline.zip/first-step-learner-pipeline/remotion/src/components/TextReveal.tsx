import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { COLORS, FONT_FAMILY } from "../constants";

// Clean word-by-word text reveal, every 7th word tinted violet as a
// lightweight "highlight" accent without needing manual markup.
export const TextReveal: React.FC<{ text: string; size?: "large" | "medium" }> = ({
  text,
  size = "medium",
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(/\s+/);
  const fontSize = size === "large" ? 96 : 56;

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: "0 160px" }}>
      <div
        style={{
          fontFamily: FONT_FAMILY,
          fontSize,
          fontWeight: 700,
          color: COLORS.textPrimary,
          textAlign: "center",
          lineHeight: 1.3,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "0 0.35em",
        }}
      >
        {words.map((word, i) => {
          const delay = i * 2;
          const progress = spring({
            frame: frame - delay,
            fps,
            config: { damping: 200, stiffness: 200 },
          });
          const opacity = interpolate(progress, [0, 1], [0, 1]);
          const translateY = interpolate(progress, [0, 1], [20, 0]);
          const isAccent = i % 7 === 0;
          return (
            <span
              key={i}
              style={{
                opacity,
                transform: `translateY(${translateY}px)`,
                color: isAccent ? COLORS.accentSoft : COLORS.textPrimary,
              }}
            >
              {word}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
