// First Step Learner brand identity — keep every color reference in
// this one file so a rebrand only ever touches one place.

export const COLORS = {
  background: "#0A0A0A",
  accent: "#7B2FF7",
  accentSoft: "#B385FF",
  textPrimary: "#F5F5F7",
  textSecondary: "#A0A0A8",
};

export const FONT_FAMILY = "'Inter', 'Segoe UI', sans-serif";
