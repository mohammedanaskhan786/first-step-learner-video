import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { Background } from "./components/Background";
import { GlassCard } from "./components/GlassCard";
import { SplitScreen } from "./components/SplitScreen";
import { TextReveal } from "./components/TextReveal";
import { WindowMockup, WindowMessage } from "./components/WindowMockup";

export type ScenePayload =
  | { text: string }
  | { leftLabel: string; rightLabel: string; leftText: string; rightText: string }
  | { title: string; messages: WindowMessage[] };

export interface TimelineScene {
  index: number;
  type: "TITLE" | "CARD" | "TEXT" | "SPLIT" | "WINDOW" | string;
  startFrame: number;
  durationInFrames: number;
  payload: ScenePayload;
}

export interface TimelineData {
  fps: number;
  totalDurationInFrames: number;
  audioFile: string;
  scenes: TimelineScene[];
}

export const MainVideo: React.FC<{ timeline: TimelineData }> = ({ timeline }) => {
  return (
    <AbsoluteFill>
      <Background />
      <Audio src={staticFile(timeline.audioFile)} />
      {timeline.scenes.map((scene) => (
        <Sequence
          key={scene.index}
          from={scene.startFrame}
          durationInFrames={scene.durationInFrames}
          name={`Scene ${scene.index} (${scene.type})`}
        >
          <SceneRenderer scene={scene} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

const SceneRenderer: React.FC<{ scene: TimelineScene }> = ({ scene }) => {
  switch (scene.type) {
    case "TITLE":
      return <TextReveal text={(scene.payload as { text: string }).text} size="large" />;
    case "CARD":
      return <GlassCard text={(scene.payload as { text: string }).text} />;
    case "SPLIT": {
      const p = scene.payload as {
        leftLabel: string;
        rightLabel: string;
        leftText: string;
        rightText: string;
      };
      return (
        <SplitScreen
          leftLabel={p.leftLabel}
          rightLabel={p.rightLabel}
          leftText={p.leftText}
          rightText={p.rightText}
        />
      );
    }
    case "WINDOW": {
      const p = scene.payload as { title: string; messages: WindowMessage[] };
      return <WindowMockup title={p.title} messages={p.messages} />;
    }
    case "TEXT":
    default:
      return <TextReveal text={(scene.payload as { text: string }).text} size="medium" />;
  }
};
