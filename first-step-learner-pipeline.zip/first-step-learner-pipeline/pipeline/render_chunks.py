"""
Renders a long video in short chunks instead of one giant render.

Why: On free Colab, rendering a full 1-hour video in a single Remotion
call often fails silently -- headless Chromium runs out of memory, or
the session hits Colab's usage limits partway through. Chunked
rendering avoids this: each chunk is a small, independent render, and
already-finished chunks are skipped on re-run -- so if Colab
disconnects or a chunk fails, you just run this script again and it
picks up where it left off.

Usage (from the project root):
    python3 pipeline/render_chunks.py --chunk-seconds 120

Then find the stitched result at remotion/out/first-step-learner.mp4
"""

import argparse
import json
import os
import subprocess
import sys


def get_total_frames(remotion_dir: str):
    timeline_path = os.path.join(remotion_dir, "public", "timeline.json")
    if not os.path.exists(timeline_path):
        raise SystemExit(
            f"'{timeline_path}' not found. Run generate_timeline.py first."
        )
    with open(timeline_path, encoding="utf-8") as f:
        data = json.load(f)
    return data["totalDurationInFrames"], data["fps"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Render a long video in resumable chunks.")
    parser.add_argument("--chunk-seconds", type=int, default=120, help="Length of each chunk, in seconds")
    parser.add_argument("--project-root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    parser.add_argument("--crf", default="18", help="Quality (lower = higher quality, slower). 16-20 is a good range.")
    args = parser.parse_args()

    root = os.path.abspath(args.project_root)
    remotion_dir = os.path.join(root, "remotion")
    out_dir = os.path.join(remotion_dir, "out")
    chunks_dir = os.path.join(out_dir, "chunks")
    os.makedirs(chunks_dir, exist_ok=True)

    total_frames, fps = get_total_frames(remotion_dir)
    chunk_frames = args.chunk_seconds * fps
    num_chunks = (total_frames + chunk_frames - 1) // chunk_frames

    print(f"Total: {total_frames} frames @ {fps}fps  ->  {num_chunks} chunks of ~{args.chunk_seconds}s each\n")

    chunk_paths = []
    for i in range(num_chunks):
        start = i * chunk_frames
        end = min(start + chunk_frames, total_frames) - 1
        chunk_file = os.path.join(chunks_dir, f"chunk_{i:03d}.mp4")
        chunk_paths.append(chunk_file)

        # Skip chunks that already rendered successfully (resumability).
        if os.path.exists(chunk_file) and os.path.getsize(chunk_file) > 0:
            print(f"[{i + 1}/{num_chunks}] Already rendered, skipping.")
            continue

        print(f"[{i + 1}/{num_chunks}] Rendering frames {start}-{end}...")
        cmd = [
            "npx", "remotion", "render",
            "src/index.ts", "MainVideo", chunk_file,
            "--codec=h264", f"--crf={args.crf}", "--pixel-format=yuv420p",
            "--gl=swiftshader",
            f"--frames={start}-{end}",
        ]
        result = subprocess.run(cmd, cwd=remotion_dir)
        if result.returncode != 0:
            print(
                f"\nChunk {i} FAILED. Nothing after this point was touched.\n"
                f"Just re-run this same command -- finished chunks are skipped "
                f"automatically, so it will resume from chunk {i}."
            )
            sys.exit(1)

    # Stitch every chunk together losslessly (no re-encoding).
    concat_list_path = os.path.join(chunks_dir, "concat_list.txt")
    with open(concat_list_path, "w", encoding="utf-8") as f:
        for p in chunk_paths:
            f.write(f"file '{os.path.abspath(p)}'\n")

    final_path = os.path.join(out_dir, "first-step-learner.mp4")
    print("\nMerging all chunks into the final video...")
    subprocess.run(
        ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_list_path, "-c", "copy", final_path],
        check=True,
    )
    print(f"\nDONE. Final video: {final_path}")


if __name__ == "__main__":
    main()
