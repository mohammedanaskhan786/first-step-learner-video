"""
Parses a plain-text script into structured Scene objects using simple
bracket tags. No manual timeline editing required -- timing is derived
later from these scenes plus the narration audio length.

Supported tags (each tag starts a new scene, and everything until the
next tag is that scene's text):

    [TITLE]
    Big statement text.

    [CARD]
    A supporting point, shown inside a glass card.

    [TEXT]
    Plain narration text with a word-by-word reveal.

    [SPLIT: Basic Prompt | Engineered System]
    Left: "Write me a blog post"
    Right: "Write a 500 word blog post for beginners, friendly tone..."

    [WINDOW: ChatGPT]
    User: "Write me a blog post"
    AI: "Sure! Here's a friendly, beginner-focused blog post..."

Untagged text at the top of the file (or any block with no tag above
it) is treated as [TEXT].
"""

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

SCENE_TAG_RE = re.compile(r"^\[(?P<tag>[A-Z_]+)(?:\s*:\s*(?P<params>.*))?\]\s*$")


@dataclass
class Scene:
    index: int
    type: str
    params: Dict[str, str]
    text: str
    word_count: int = field(init=False)

    def __post_init__(self) -> None:
        self.word_count = max(len(self.text.split()), 1)


def parse_script(path: str) -> List[Scene]:
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    lines = raw.splitlines()
    scenes: List[Scene] = []
    current_tag: Optional[str] = None
    current_params: Dict[str, str] = {}
    buffer: List[str] = []
    idx = 0

    def flush() -> None:
        nonlocal idx, buffer, current_tag, current_params
        text = "\n".join(buffer).strip()
        if not text:
            buffer = []
            return
        tag = current_tag or "TEXT"
        scenes.append(Scene(index=idx, type=tag, params=dict(current_params), text=text))
        idx += 1
        buffer = []

    for line in lines:
        match = SCENE_TAG_RE.match(line.strip())
        if match:
            flush()
            current_tag = match.group("tag")
            current_params = _parse_params(current_tag, match.group("params") or "")
        else:
            buffer.append(line)

    flush()

    if not scenes:
        raise ValueError(f"No content parsed from script: {path}")

    return scenes


def _parse_params(tag: str, raw: str) -> Dict[str, str]:
    if tag == "SPLIT":
        parts = [p.strip() for p in raw.split("|")]
        left = parts[0] if len(parts) > 0 and parts[0] else "Before"
        right = parts[1] if len(parts) > 1 and parts[1] else "After"
        return {"left_label": left, "right_label": right}
    if tag == "WINDOW":
        return {"window_title": raw.strip() or "AI Assistant"}
    return {}
