"""
Converts a tagged script.txt into a single narration audio file using
gTTS (free, no API key needed). Strips tags, joins all scene text in
order, and synthesizes one continuous narration track -- this becomes
the master timeline audio that generate_timeline.py reads.
"""

import argparse

from gtts import gTTS
from script_parser import parse_script


def script_to_narration_text(script_path: str) -> str:
    scenes = parse_script(script_path)
    lines = []
    for scene in scenes:
        if scene.type in ("SPLIT", "WINDOW"):
            for line in scene.text.splitlines():
                cleaned = line.split(":", 1)[-1].strip().strip('"')
                if cleaned:
                    lines.append(cleaned)
        else:
            lines.append(scene.text.replace("\n", " "))
    return " ... ".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--script", required=True)
    parser.add_argument("--out", default="narration.mp3")
    parser.add_argument("--lang", default="en")
    args = parser.parse_args()

    text = script_to_narration_text(args.script)
    tts = gTTS(text=text, lang=args.lang, slow=False)
    tts.save(args.out)
    print(f"Narration written to {args.out}")


if __name__ == "__main__":
    main()
