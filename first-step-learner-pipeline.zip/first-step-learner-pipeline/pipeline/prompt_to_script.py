"""
Turns a single topic prompt into a fully tagged script.txt using the
Gemini API. This is what makes the pipeline "one prompt -> video":
no manual script writing needed.
"""

import argparse
import os

import google.generativeai as genai

SYSTEM_INSTRUCTIONS = """You are a scriptwriter for a YouTube education channel called \
"First Step Learner" that teaches practical AI skills to complete beginners.

Write a short (60-90 second spoken) video script on the given topic.
Output ONLY the script text using this exact tag format, nothing else \
(no markdown, no explanations, no extra commentary):

[TITLE]
<a short, punchy hook line>

[TEXT]
<a sentence or two of plain narration>

[CARD]
<one key point, one to two sentences>

[SPLIT: <short left label> | <short right label>]
Left: "<a basic/naive version>"
Right: "<a better/engineered version>"

[WINDOW: <a short app/tool name, e.g. ChatGPT>]
User: "<a short realistic user prompt related to the topic>"
AI: "<a short realistic AI reply, 1-2 sentences>"

[TEXT]
<narration>

[CARD]
<a key takeaway>

[TITLE]
<a short closing line, e.g. call to action or "see you next time">

Rules:
- Use [TITLE] exactly twice: once to open, once to close.
- Use [SPLIT: ... | ...] exactly once, with a genuine before/after or
  basic/advanced comparison relevant to the topic.
- Use [WINDOW: ...] exactly once, with one short realistic User/AI
  exchange relevant to the topic.
- Use [TEXT] and [CARD] as needed in between, 5-9 scenes total.
- Keep every scene short enough to be spoken naturally in a few seconds.
- Do not include stage directions, emojis, or any text outside the tags.
"""


def generate_script(topic: str, api_key: str) -> str:
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-2.0-flash")
    response = model.generate_content([SYSTEM_INSTRUCTIONS, f"Topic: {topic}"])
    text = response.text.strip()
    # Some models wrap output in markdown fences even when told not to.
    text = text.strip("`").strip()
    if text.lower().startswith("text"):
        text = text[4:].strip()
    return text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", required=True)
    parser.add_argument("--api-key", default=os.environ.get("GEMINI_API_KEY"))
    parser.add_argument("--out", default="script.txt")
    args = parser.parse_args()

    if not args.api_key:
        raise SystemExit("Set GEMINI_API_KEY env var or pass --api-key")

    script_text = generate_script(args.topic, args.api_key)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(script_text)

    print(f"Script written to {args.out}")
    print("---")
    print(script_text)


if __name__ == "__main__":
    main()
