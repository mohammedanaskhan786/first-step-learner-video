"""
Main orchestrator: script.txt + audio.mp3/wav -> remotion/public/timeline.json

Usage:
    python3 generate_timeline.py --script path/to/script.txt --audio path/to/narration.mp3

This is the piece that removes manual timeline editing: it distributes
the known narration length across scenes proportionally to each
scene's word count (clamped to sane min/max bounds), then rescales so
the scenes sum exactly to the audio's real duration. The result is a
frame-accurate timeline Remotion can play back with zero hand tuning.
"""

import argparse
import json
import os
import shutil

from audio_utils import get_audio_duration_seconds
from config import FPS, MAX_SCENE_SECONDS, MIN_SCENE_SECONDS
from script_parser import Scene, parse_script


def build_payload(scene: Scene) -> dict:
    if scene.type == "SPLIT":
        left_lines, right_lines = [], []
        target = None
        for line in scene.text.splitlines():
            stripped = line.strip()
            if stripped.lower().startswith("left:"):
                target = left_lines
                stripped = stripped[len("left:"):].strip()
            elif stripped.lower().startswith("right:"):
                target = right_lines
                stripped = stripped[len("right:"):].strip()
            stripped = stripped.strip('"')
            if stripped and target is not None:
                target.append(stripped)
        return {
            "leftLabel": scene.params.get("left_label", "Before"),
            "rightLabel": scene.params.get("right_label", "After"),
            "leftText": " ".join(left_lines),
            "rightText": " ".join(right_lines),
        }
    if scene.type == "WINDOW":
        messages = []
        for line in scene.text.splitlines():
            stripped = line.strip()
            if stripped.lower().startswith("user:"):
                role, content = "user", stripped[len("user:"):]
            elif stripped.lower().startswith("ai:"):
                role, content = "ai", stripped[len("ai:"):]
            else:
                continue
            content = content.strip().strip('"')
            if content:
                messages.append({"role": role, "text": content})
        return {
            "title": scene.params.get("window_title", "AI Assistant"),
            "messages": messages,
        }
    return {"text": scene.text}


def compute_durations(scenes, total_duration: float):
    total_words = sum(s.word_count for s in scenes)
    raw = []
    for s in scenes:
        share = total_duration * (s.word_count / total_words)
        share = max(MIN_SCENE_SECONDS, min(MAX_SCENE_SECONDS, share))
        raw.append(share)

    scale = total_duration / sum(raw)
    return [r * scale for r in raw]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate a Remotion timeline.json from a script + audio file."
    )
    parser.add_argument("--script", required=True, help="Path to the .txt script")
    parser.add_argument("--audio", required=True, help="Path to the .mp3/.wav narration")
    parser.add_argument(
        "--out-dir",
        default=os.path.join(os.path.dirname(__file__), "..", "remotion", "public"),
        help="Remotion public/ directory to write timeline.json + audio into",
    )
    args = parser.parse_args()

    scenes = parse_script(args.script)
    total_duration = get_audio_duration_seconds(args.audio)
    durations = compute_durations(scenes, total_duration)

    timeline = []
    cursor = 0.0
    for scene, dur in zip(scenes, durations):
        start = cursor
        timeline.append(
            {
                "index": scene.index,
                "type": scene.type,
                "startFrame": round(start * FPS),
                "durationInFrames": max(1, round(dur * FPS)),
                "payload": build_payload(scene),
            }
        )
        cursor += dur

    # Snap the final scene's end to the exact audio length so there's
    # never a silent tail or an abrupt cutoff.
    total_frames = round(total_duration * FPS)
    if timeline:
        last = timeline[-1]
        last["durationInFrames"] = max(1, total_frames - last["startFrame"])

    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    audio_ext = os.path.splitext(args.audio)[1]
    audio_filename = "audio" + audio_ext

    timeline_path = os.path.join(out_dir, "timeline.json")
    with open(timeline_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "fps": FPS,
                "totalDurationInFrames": total_frames,
                "audioFile": audio_filename,
                "scenes": timeline,
            },
            f,
            indent=2,
        )

    shutil.copyfile(args.audio, os.path.join(out_dir, audio_filename))

    print(f"Wrote timeline:  {timeline_path}")
    print(f"Copied audio to: {os.path.join(out_dir, audio_filename)}")
    print(f"Total duration:  {total_duration:.2f}s  ({total_frames} frames @ {FPS}fps)")
    print(f"Scenes parsed:   {len(timeline)}")


if __name__ == "__main__":
    main()
