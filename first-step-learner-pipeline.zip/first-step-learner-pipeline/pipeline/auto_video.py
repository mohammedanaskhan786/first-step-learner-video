"""
THE single-command entry point: a topic string -> a finished MP4.

Chains together:
  1. Gemini API   -> writes a fully tagged script
  2. gTTS         -> synthesizes one narration audio track from it
  3. generate_timeline.py -> frame-accurate timeline.json
  4. Remotion CLI -> final rendered MP4

Usage (from the project root):
    python3 pipeline/auto_video.py --topic "What is a system prompt?"
"""

import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gtts import gTTS
from prompt_to_script import generate_script
from script_to_speech import script_to_narration_text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", required=True, help="One-line video topic, e.g. 'What is a system prompt?'")
    parser.add_argument("--api-key", default=os.environ.get("GEMINI_API_KEY"))
    parser.add_argument(
        "--project-root",
        default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."),
    )
    args = parser.parse_args()

    if not args.api_key:
        raise SystemExit(
            "No Gemini API key found. Set it with:\n"
            "  import os; os.environ['GEMINI_API_KEY'] = 'your-key-here'\n"
            "Get a free key at https://aistudio.google.com/apikey"
        )

    root = os.path.abspath(args.project_root)
    script_path = os.path.join(root, "generated_script.txt")
    audio_path = os.path.join(root, "generated_narration.mp3")

    print(">>> [1/4] Writing script with Gemini...")
    script_text = generate_script(args.topic, args.api_key)
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(script_text)
    print(script_text)

    print("\n>>> [2/4] Synthesizing narration with gTTS...")
    narration_text = script_to_narration_text(script_path)
    gTTS(text=narration_text, lang="en", slow=False).save(audio_path)

    print(">>> [3/4] Building frame-accurate timeline...")
    subprocess.run(
        [
            sys.executable,
            os.path.join(root, "pipeline", "generate_timeline.py"),
            "--script", script_path,
            "--audio", audio_path,
        ],
        check=True,
    )

    print(">>> [4/4] Rendering final video (this takes a few minutes)...")
    subprocess.run(
        [
            "npx", "remotion", "render",
            "src/index.ts", "MainVideo", "out/first-step-learner.mp4",
            "--codec=h264", "--crf=16", "--pixel-format=yuv420p", "--gl=swiftshader",
        ],
        cwd=os.path.join(root, "remotion"),
        check=True,
    )

    print("\n>>> DONE. Output: remotion/out/first-step-learner.mp4")


if __name__ == "__main__":
    main()
