"""
Synthesizes narration for a script in YOUR OWN cloned voice, using a
short sample recording. Uses Coqui XTTS-v2 (open source, runs locally
or on a Colab GPU) -- no cloud voice-cloning API/account needed.

IMPORTANT LICENSE NOTE:
XTTS-v2's model weights ship under the Coqui Public Model License
(CPML), which is non-commercial. If "First Step Learner" is a
monetized YouTube channel, check that license (or Coqui's paid
commercial license) before shipping cloned-voice narration publicly.
This script is provided for testing / personal use; it is not legal
advice.

Usage:
    python3 pipeline/voice_clone.py \
        --script script.txt \
        --voice-sample my_voice_sample.wav \
        --out narration.wav
"""

import argparse
import os

from script_to_speech import script_to_narration_text


def clone_voice_narration(
    script_path: str, voice_sample_path: str, out_path: str, language: str = "en"
) -> None:
    # Imported lazily so the rest of the pipeline (which doesn't need
    # TTS/torch) stays lightweight and fast to install.
    import torch
    from TTS.api import TTS

    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cpu":
        print("WARNING: no GPU detected -- voice cloning on CPU is slow. "
              "In Colab, use Runtime > Change runtime type > GPU.")

    tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

    text = script_to_narration_text(script_path)
    tts.tts_to_file(
        text=text,
        speaker_wav=voice_sample_path,
        language=language,
        file_path=out_path,
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Clone your voice from a short sample and narrate the full script with it."
    )
    parser.add_argument("--script", required=True, help="Path to your tagged script.txt")
    parser.add_argument(
        "--voice-sample",
        required=True,
        help="A clean 10-30 second WAV/MP3 of your voice, no background noise or music",
    )
    parser.add_argument("--out", default="narration.wav")
    parser.add_argument("--language", default="en", help="Language code, e.g. en, hi, es")
    args = parser.parse_args()

    # XTTS-v2 requires agreeing to Coqui's terms on first run.
    os.environ.setdefault("COQUI_TOS_AGREED", "1")

    clone_voice_narration(args.script, args.voice_sample, args.out, args.language)
    print(f"Cloned narration written to {args.out}")


if __name__ == "__main__":
    main()
