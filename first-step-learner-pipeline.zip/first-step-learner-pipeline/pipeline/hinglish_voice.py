"""
Generates automated Hinglish (Hindi + English mixed) narration using
Microsoft Edge's free neural TTS voices -- no API key, no account,
no cloud billing, and no copyrighted material involved.

IMPORTANT: For long scripts (many scenes / thousands of words),
sending the entire narration as one giant TTS request is unreliable
-- it can time out or fail silently. This version synthesizes each
scene SEPARATELY, then stitches the pieces into one continuous audio
file with a short pause between scenes. This is far more robust for
long (e.g. 1-hour) scripts and retries automatically on failure.

Good voices for Hinglish:
    hi-IN-SwaraNeural   -- female, Hindi (default)
    hi-IN-MadhurNeural  -- male, Hindi
    en-IN-NeerjaNeural  -- female, Indian English
    en-IN-PrabhatNeural -- male, Indian English

List all available voices any time with:
    edge-tts --list-voices

Usage:
    python3 pipeline/hinglish_voice.py --script script.txt --out narration.mp3
"""

import argparse
import asyncio
import os
import sys
import tempfile

import edge_tts
from pydub import AudioSegment

from script_parser import parse_script

DEFAULT_VOICE = "hi-IN-SwaraNeural"
GAP_MS = 350  # silence between scenes, in milliseconds


def _scene_texts(script_path: str):
    """Splits the script into one narration chunk per scene, in order."""
    scenes = parse_script(script_path)
    texts = []
    for scene in scenes:
        if scene.type in ("SPLIT", "WINDOW"):
            lines = []
            for line in scene.text.splitlines():
                cleaned = line.split(":", 1)[-1].strip().strip('"')
                if cleaned:
                    lines.append(cleaned)
            texts.append(" ".join(lines))
        else:
            texts.append(scene.text.replace("\n", " "))
    return [t.strip() for t in texts if t.strip()]


async def _synthesize_chunk(text: str, voice: str, rate: str, out_path: str, retries: int = 3) -> None:
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            communicate = edge_tts.Communicate(text, voice, rate=rate)
            await communicate.save(out_path)
            if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
                return
            raise RuntimeError("Output file was empty")
        except Exception as e:  # noqa: BLE001 -- we want to retry on anything and report clearly
            last_err = e
            print(f"    Attempt {attempt}/{retries} failed: {e}", file=sys.stderr)
            await asyncio.sleep(2)
    raise RuntimeError(
        f"Failed to synthesize a scene after {retries} attempts.\n"
        f"Last error: {last_err}\n"
        f"Scene text (first 100 chars): {text[:100]!r}"
    )


async def synthesize_long_script(script_path: str, voice: str, rate: str, out_path: str) -> None:
    texts = _scene_texts(script_path)
    if not texts:
        raise ValueError(f"No narration text found in {script_path}")

    print(f"  {len(texts)} scenes to synthesize...")
    combined = AudioSegment.silent(duration=0)
    silence_gap = AudioSegment.silent(duration=GAP_MS)
    out_format = "wav" if out_path.lower().endswith(".wav") else "mp3"

    with tempfile.TemporaryDirectory() as tmp_dir:
        for i, text in enumerate(texts):
            chunk_path = os.path.join(tmp_dir, f"chunk_{i:04d}.mp3")
            print(f"  [{i + 1}/{len(texts)}] Synthesizing: {text[:50]}...")
            await _synthesize_chunk(text, voice, rate, chunk_path)
            segment = AudioSegment.from_file(chunk_path)
            combined += segment + silence_gap

    combined.export(out_path, format=out_format)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate automated Hinglish narration audio, scene by scene (robust for long scripts)."
    )
    parser.add_argument("--script", required=True, help="Path to your tagged script.txt")
    parser.add_argument("--out", default="narration.mp3")
    parser.add_argument(
        "--voice",
        default=DEFAULT_VOICE,
        help="Edge TTS voice name, e.g. hi-IN-SwaraNeural, hi-IN-MadhurNeural, en-IN-NeerjaNeural",
    )
    parser.add_argument(
        "--rate",
        default="+0%",
        help="Speaking speed adjustment, e.g. +10%% (faster), -10%% (slower)",
    )
    args = parser.parse_args()

    if not os.path.exists(args.script):
        raise SystemExit(f"Script file not found: {args.script}")

    asyncio.run(synthesize_long_script(args.script, args.voice, args.rate, args.out))
    print(f"Hinglish narration written to {args.out} (voice: {args.voice})")


if __name__ == "__main__":
    main()
