"""Brand configuration for the First Step Learner video pipeline."""

FPS = 30
WIDTH = 1920
HEIGHT = 1080

COLORS = {
    "background": "#0A0A0A",
    "accent": "#7B2FF7",
    "accent_soft": "#B385FF",
    "text_primary": "#F5F5F7",
    "text_secondary": "#A0A0A8",
}

FONT_FAMILY = "Inter, 'Segoe UI', sans-serif"

# Guardrails for the proportional timing pass so no single scene
# becomes a flash-frame or a multi-minute wall of text.
MIN_SCENE_SECONDS = 1.5
MAX_SCENE_SECONDS = 25.0
