"""Audio inspection helpers. Requires ffmpeg/ffprobe on PATH (pydub
shells out to it -- this is the only heavy dependency)."""

from pydub.utils import mediainfo


def get_audio_duration_seconds(path: str) -> float:
    info = mediainfo(path)
    duration = info.get("duration")
    if duration is None:
        raise RuntimeError(
            f"Could not read duration for '{path}'. "
            "Make sure ffmpeg/ffprobe is installed and on your PATH."
        )
    return float(duration)
